class Q4{
	public static void main(String args[]){
		short a=5;
		byte b=(byte)a;
		System.out.println(+b);
	}
}