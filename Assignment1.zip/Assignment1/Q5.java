class Q5{
	public static void main(String a[]){
		String nm =a[0];
		System.out.println("Welcome "+nm);
	}
}