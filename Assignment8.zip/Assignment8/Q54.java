package Assignment8;

public class Q54 {

	public static void main(String[] args) {
		String S="reverse";
		
		StringBuilder sb=new StringBuilder(S);
		
		sb.reverse();
		
		System.out.println("reverse of string : "+sb);

	}

}
