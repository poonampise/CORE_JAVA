package Assignment8;

public class Q55 {

	public static void main(String[] args) {
	
		String s="this is word count";
		
		System.out.println("word count : "+s.split(" ").length);
		
	}

}
