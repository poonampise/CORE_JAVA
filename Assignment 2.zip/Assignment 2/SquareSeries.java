import java.util.*;
public class SquareSeries{

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number");

        int num = sc.nextInt();
        int a = 2;
        int square = 0;

        for(int i = 1; i<=num; i++)
        {
             square = i^2;
            // System.out.println(square);
        }
        System.out.println(square);

    }
}






